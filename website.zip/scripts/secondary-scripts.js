var max = 20;

for(var i = 0; i < max; i++ ) {
    console.log(i);
}